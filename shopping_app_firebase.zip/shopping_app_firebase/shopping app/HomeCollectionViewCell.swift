//
//  HomeCollectionViewCell.swift
//  shopping app
//
//  Created by Nina on 2016/11/28.
//  Copyright © 2016年 Nina. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    @IBOutlet var thumbnailImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
}
